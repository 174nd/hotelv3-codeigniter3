<!-- DataTables -->
<script src="<?= base_url('plugins/datatables/jquery.dataTables.min.js') ?>"></script>
<script src="<?= base_url('plugins/datatables-bs4/js/dataTables.bootstrap4.min.js') ?>"></script>
<script src="<?= base_url('plugins/datatables-responsive/js/dataTables.responsive.min.js') ?>"></script>
<script src="<?= base_url('plugins/datatables-responsive/js/responsive.bootstrap4.min.js') ?>"></script>

<!-- bootstrap Date picker -->
<script src="<?= base_url('plugins/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js') ?>"></script>


<!-- bootstrap clockpicker -->
<script src="<?= base_url('plugins/bootstrap-clockpicker/bootstrap-clockpicker.min.js') ?>"></script>


<!-- Select2 -->
<script src="<?= base_url('plugins/select2/js/select2.full.min.js') ?>"></script>


<!-- jQuery Mask 1.14.16 -->
<script src="<?= base_url('plugins/jquery-mask/jquery.mask.min.js'); ?>"></script>


<!-- Moment -->
<script src="<?= base_url('plugins/moment/moment.min.js') ?>"></script>


<!-- Toastr -->
<script src="<?= base_url('plugins/toastr/toastr.min.js') ?>"></script>