<!-- DataTables -->
<link rel="stylesheet" href="<?= base_url('plugins/datatables-bs4/css/dataTables.bootstrap4.min.css') ?>">
<link rel="stylesheet" href="<?= base_url('plugins/datatables-responsive/css/responsive.bootstrap4.min.css') ?>">


<!-- Bootstrap Date Picker -->
<link rel="stylesheet" href="<?= base_url('plugins/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css') ?>">


<!-- bootstrap Clock Picker -->
<link rel="stylesheet" href="<?= base_url('plugins/bootstrap-clockpicker/bootstrap-clockpicker.min.css') ?>">


<!-- Select2 -->
<link rel="stylesheet" href="<?= base_url('plugins/select2/css/select2.min.css') ?>">
<link rel="stylesheet" href="<?= base_url('plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css') ?>">


<!-- Toastr -->
<link rel="stylesheet" href="<?= base_url('plugins/toastr/toastr.min.css') ?>">